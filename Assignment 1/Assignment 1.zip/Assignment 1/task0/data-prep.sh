#!bin bash
python3 ./data-prep.py