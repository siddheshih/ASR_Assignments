import os
import sys
p=[]
with open('./corpus/data/data-info.txt','r') as file: 
   
    # reading each line     
	for line in file:
		a=[]          
		for word in line.split():
			a.append(word) 
			#print(word)
   
            # displaying the words            
		p.append(a)  

path='./corpus/data/test'
if not os.path.exists(path):
	os.makedirs(path)
path='./corpus/data/train'
if not os.path.exists(path):
    os.makedirs(path)
path='./corpus/data/truetest'
if not os.path.exists(path):
    os.makedirs(path)

with open('./corpus/data/transcriptions.txt', 'r') as f1:
    lines = f1.readlines()


#print(p[0])
root='./corpus/data/wav'
root2 = 'corpus/data/wav'
sys.stdout = open("./corpus/data/train/wav.scp", "w")
for j in p[0][1:]:
	path=os.path.join(root,j)

	arr=os.listdir(path)
	for i in arr:
		path2=os.path.join(root2,j,i)
		print(i[0:-4] + ' ' + path2)

sys.stdout.close()

sys.stdout = open("./corpus/data/test/wav.scp", "w")
for j in p[1][1:]:
	path=os.path.join(root,j)

	arr=os.listdir(path)
	for i in arr:
		path2=os.path.join(root2,j,i)
		print(i[0:-4] + '\t' + path2)

sys.stdout.close()

sys.stdout = open("./corpus/data/truetest/wav.scp", "w")
for j in p[2][1:]:
	path=os.path.join(root,j)

	arr=os.listdir(path)
	for i in arr:
		path2=os.path.join(root2,j,i)
		print(i[0:-4] + '\t' + path2)

sys.stdout.close()

### For Generating txt ####
sys.stdout = open("./corpus/data/train/text", "w")
for j in p[0][1:]:
	path=os.path.join(root,j)

	arr=os.listdir(path)
	for i in arr:
		for l in lines:
			t=i[0:-4]+'\t'
			if t in l:
				print(l,end='')
				#print(t)
		#path2=os.path.join(root2,j,i)
		#print(i[0:-4] + ' ' + path2)

sys.stdout.close()

sys.stdout = open("./corpus/data/test/text", "w")
for j in p[1][1:]:
	path=os.path.join(root,j)

	arr=os.listdir(path)
	for i in arr:
		for l in lines:
			t=i[0:-4]+'\t'
			if t in l:
				print(l,end='')
		#path2=os.path.join(root2,j,i)
		#print(i[0:-4] + ' ' + path2)

sys.stdout.close()

sys.stdout = open("./corpus/data/truetest/text", "w")
for j in p[2][1:]:
	path=os.path.join(root,j)

	arr=os.listdir(path)
	for i in arr:
		for l in lines:
			t=i[0:-4]+'\t'
			if t in l:
				print(l,end='')
		#path2=os.path.join(root2,j,i)
		#print(i[0:-4] + ' ' + path2)

sys.stdout.close()
	#print(path2)


"""
UTTtospk files are being configured 
"""

sys.stdout = open("./corpus/data/train/utt2spk", "w")

for j in p[0][1:]:
	path=os.path.join(root,j)
	k=0

	arr=os.listdir(path)
	for i in arr:
		
		path2=os.path.join(root2,j,i)
		k=k+1
		print(i[0:-4] + ' ' +j)
		

sys.stdout.close()

sys.stdout = open("./corpus/data/test/utt2spk", "w")
for j in p[1][1:]:
	path=os.path.join(root,j)

	arr=os.listdir(path)
	for i in arr:
		path2=os.path.join(root2,j,i)
		print(i[0:-4] + ' ' + j)

sys.stdout.close()

sys.stdout = open("./corpus/data/truetest/utt2spk", "w")
for j in p[2][1:]:
	path=os.path.join(root,j)

	arr=os.listdir(path)
	for i in arr:
		path2=os.path.join(root2,j,i)
		print(i[0:-4] + ' ' + j)

sys.stdout.close()

os.system('sort -o ./corpus/data/train/text ./corpus/data/train/text')
os.system('sort -o ./corpus/data/train/utt2spk ./corpus/data/train/utt2spk')
os.system('sort -o ./corpus/data/train/wav.scp ./corpus/data/train/wav.scp')

os.system('sort ./corpus/data/test/text -o ./corpus/data/test/text')
os.system('sort ./corpus/data/test/utt2spk -o ./corpus/data/test/utt2spk')
os.system('sort ./corpus/data/test/wav.scp -o ./corpus/data/test/wav.scp')

os.system('sort ./corpus/data/truetest/text -o ./corpus/data/truetest/text')
os.system('sort ./corpus/data/truetest/utt2spk -o ./corpus/data/truetest/utt2spk')
os.system('sort ./corpus/data/truetest/wav.scp -o ./corpus/data/truetest/wav.scp')

os.system( '[ ! -L "utils" ] && ln -s ../../wsj/s5/utils')
os.system(' ./utils/utt2spk_to_spk2utt.pl ./corpus/data/train/utt2spk > ./corpus/data/train/spk2utt')
os.system( '[ ! -L "utils" ] && ln -s ../../wsj/s5/utils')
os.system(' ./utils/utt2spk_to_spk2utt.pl ./corpus/data/test/utt2spk > ./corpus/data/test/spk2utt')
os.system( '[ ! -L "utils" ] && ln -s ../../wsj/s5/utils')
os.system(' ./utils/utt2spk_to_spk2utt.pl ./corpus/data/truetest/utt2spk > ./corpus/data/truetest/spk2utt')

os.system('sort ./corpus/data/truetest/spk2utt -o ./corpus/data/truetest/spk2utt')
os.system('sort ./corpus/data/test/spk2utt -o ./corpus/data/test/spk2utt')
os.system('sort ./corpus/data/train/spk2utt -o ./corpus/data/train/spk2utt')

os.system('bash utils/fix_data_dir.sh ./corpus/data/train')
os.system('bash utils/fix_data_dir.sh ./corpus/data/test')
os.system('bash utils/fix_data_dir.sh ./corpus/data/truetest')
