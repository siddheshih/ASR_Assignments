import os
import sys

c=sys.argv
z=1
print(c[1:])
p=c[1:]
print(p)
for i in p:
	with open("./exp/tri1/ctm") as doc:
		for line in doc:
			c=' '+i+' '
			if c in line:
				x= line.strip().split()
				os.system('sox ./corpus/data/wav/{}/{}.wav ./outputaudio/wave{}.wav trim {} {}'.format(x[0][:15],x[0],str(z).zfill(2),x[2],x[3]))
				z=z+1


				print (line)
