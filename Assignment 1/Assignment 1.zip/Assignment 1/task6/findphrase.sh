#!/bin/sh

cd ./
steps/get_train_ctm.sh data/train/ data/lang exp/tri1
mkdir outputaudio
# grep $1 ../exp/tri1/ctm >> all_trans.txt
# echo $1
python3 clipping_fn.py $1
